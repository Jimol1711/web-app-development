Tarea 1 - CC5002
Nombre: Juan Ignacio Molina
Los nombres de las regiones y las comunas los obtuve de la siguiente fuente: https://gist.github.com/juanbrujo/0fd2f4d126b3ce5a95a7dd1f28b3d8dd#file-comunas-regiones-json
La imagen de los juegos panamericanos de la portada es de dominio público.
Las imagenes utilizadas para las artesanías son de mi autoría.

La entrega incluye los 7 archivos html pedidos y uno extra para mostrar la imagen de informacion-artesano en tamaño grande, junto con un archivo CSS para las páginas de registro, uno para los listados y uno para las paginas de información, dos archivos
javascript para los formularios, y 6 imágenes que corresponden al logo de los juegos panamericanos y las de artesanías que son de mi autoría.
