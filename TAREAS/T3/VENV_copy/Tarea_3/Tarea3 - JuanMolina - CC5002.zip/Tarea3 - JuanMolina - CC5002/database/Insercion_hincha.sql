INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (90103,1,"Miguel","Miguel@gmail.com","+56942473243","hola que tal");
INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (100108,2,"Bastián","Bastian@gmail.com","+56983759465","foo bar baz");
INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (130606,2,"Manuel","Manuel@gmail.com","+56901025364","inserte comentario");
INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (90110,1,"Roberta","ROberta@gmail.com","+56978394625","hola");
INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (130601,2,"Consuelo","Consuelo@gmail.com","+56903425465","chao");
INSERT INTO hincha (comuna_id, modo_transporte, nombre, email, celular, comentarios) VALUES (50102,1,"Francisca","Francisca@gmail.com","+56975849576","xd");