INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (10202,"lorem ipsum","Juan","Juan@gmail.com","+56912121212");
INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (50304,"lorem ipsum","Pedro","Pedro@gmail.com","+56923232323");
INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (60110,"lorem ipsum","Diego","Diego@gmail.com","+56934343434");
INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (70105,"lorem ipsum","Andrea","Andrea@gmail.com","+56945454545");
INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (80208,"lorem ipsum","Rocío","Rocío@gmail.com","+56956565656");
INSERT INTO artesano (comuna_id, descripcion_artesania, nombre, email, celular) VALUES (100405,"lorem ipsum","Martín","Martín@gmail.com","+56956565656");